﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace CSVProject
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string filePath = "C:\\Users\\User\\Desktop\\Projects\\CsvProject.csv";

            WriteToCsvFile(filePath);

            List<Person> people = ReadFromCsvFile(filePath);

            CalculateAndDisplayResults(people);
        }

        static void WriteToCsvFile(string filePath)
        {
            int count = 1000;
            Random random = new Random();
            try
            {
                using (StreamWriter streamWriter = new StreamWriter(filePath))
                {
                    streamWriter.WriteLine("FirstName,LastName,Age,Weight,Gender");
                    string[] maleFirstNames = { "Yosef", "Rony", "Moshe", "Tzvi", "Ben" };
                    string[] femaleFirstNames = { "Shira", "Shevi", "Tami", "Rivka", "Noa" };
                    string[] lastNames = { "Levi", "Israeli", "Shor", "Cohen", "Silver" };
                    Dictionary<string, string[]> firstNames = new Dictionary<string, string[]>();
                    firstNames.Add("male", maleFirstNames);
                    firstNames.Add("female", femaleFirstNames);

                    for (int i = 0; i < count; i++)
                    {
                        string gender = (random.Next(2) == 0) ? "male" : "female";
                        string firstName = string.Empty;
                        switch (gender)
                        {
                            case "male":
                                firstName = firstNames["male"][random.Next(firstNames["male"].Length)];
                                break;
                            case "female":
                                firstName = firstNames["female"][random.Next(firstNames["female"].Length)];
                                break;
                        }

                        string lastName = lastNames[random.Next(lastNames.Length)];
                        int age = random.Next(18, 71);
                        int weight = random.Next(100, 200);

                        streamWriter.WriteLine($"{firstName},{lastName},{age},{weight},{gender}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error while writing to CSV file: {ex.Message}");
            }
        }

        static List<Person> ReadFromCsvFile(string filePath)
        {
            List<Person> people = new List<Person>();
            try
            {


                using (StreamReader streamReader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        if (!line.StartsWith("FirstName"))
                        {
                            string[] values = line.Split(',');
                            string firstName = values[0];
                            string lastName = values[1];
                            int age = int.Parse(values[2]);
                            double weight = double.Parse(values[3]);
                            string gender = values[4];

                            people.Add(new Person(
                                firstName,
                                lastName,
                                age,
                                weight,
                                gender
                                ));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error while reading from CSV file: {ex.Message}");
            }
            return people;
        }

        static void CalculateAndDisplayResults(List<Person> people)
        {
            double AgeAverage = people.Average(person => person.Age);
            Console.WriteLine($"The average age of the people: {AgeAverage}");

            int weightCount = people.Count(person => person.Weight >= 120 && person.Weight <= 140);
            Console.WriteLine($"The total number of people weighing between 120lbs and 140lbs: {weightCount}");

            double? averageAgeBetween120And140 = people
                .Where(person => person.Weight >= 120 && person.Weight <= 140)?
                .Average(person => person.Age);
            Console.WriteLine($"The average age of people weighing between 120lbs and 140lbs: {averageAgeBetween120And140:F2}");
        }
    }
    class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public double Weight { get; set; }
        public string Gender { get; set; }

        public Person(string firstName, string lastName, int age, double weight, string gender)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
            Weight = weight;
            Gender = gender;
        }
    }

}

